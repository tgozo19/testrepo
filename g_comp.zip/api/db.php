<?php
    $con = new pdo("mysql:host=localhost;dbname=gocard","debian-sys-maint","RmuvUPNCuUwH1sqU");
?>